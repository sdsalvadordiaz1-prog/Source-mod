package com.weaponsmod.client;

import com.weaponsmod.client.screen.WeaponCraftingScreen;
import com.weaponsmod.screen.ModScreenHandlers;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

@Environment(EnvType.CLIENT)
public class WeaponsModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HandledScreens.register(ModScreenHandlers.WEAPON_CRAFTING, WeaponCraftingScreen::new);
    }
}
