package com.weaponsmod.client;

import com.weaponsmod.client.screen.WeaponCraftingScreen;
import com.weaponsmod.entity.ModEntities;
import com.weaponsmod.screen.ModScreenHandlers;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.gui.screen.ingame.HandledScreens;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

@Environment(EnvType.CLIENT)
public class WeaponsModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HandledScreens.register(ModScreenHandlers.WEAPON_CRAFTING, WeaponCraftingScreen::new);

        // Register renderers for bullet and grenade entities
        EntityRendererRegistry.register(ModEntities.BULLET, FlyingItemEntityRenderer::new);
        EntityRendererRegistry.register(ModEntities.GRENADE, FlyingItemEntityRenderer::new);
    }
}
