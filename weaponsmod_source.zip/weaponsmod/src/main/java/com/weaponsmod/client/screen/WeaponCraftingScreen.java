package com.weaponsmod.client.screen;

import com.weaponsmod.recipe.WeaponRecipe;
import com.weaponsmod.recipe.WeaponRecipeManager;
import com.weaponsmod.screen.WeaponCraftingScreenHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

public class WeaponCraftingScreen extends HandledScreen<WeaponCraftingScreenHandler> {

    private static final Identifier TEXTURE = new Identifier("weaponsmod", "textures/gui/weapon_crafting.png");
    private static final int GUI_WIDTH = 195;
    private static final int GUI_HEIGHT = 166;

    // Recipe list panel
    private static final int LIST_X = 5;
    private static final int LIST_Y = 18;
    private static final int LIST_ENTRY_H = 20;
    private static final int LIST_W = 90;

    private int activeTab = 0; // 0 = Armas, 1 = Balas
    private List<WeaponRecipe> currentRecipes;
    private int selectedIndex = -1;
    private int scrollOffset = 0;
    private static final int MAX_VISIBLE = 6;

    public WeaponCraftingScreen(WeaponCraftingScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
        this.backgroundWidth = GUI_WIDTH;
        this.backgroundHeight = GUI_HEIGHT;
        refreshRecipes();
    }

    private void refreshRecipes() {
        WeaponRecipe.RecipeCategory cat = (activeTab == 0)
                ? WeaponRecipe.RecipeCategory.WEAPON
                : WeaponRecipe.RecipeCategory.AMMO;
        currentRecipes = WeaponRecipeManager.getByCategory(cat);
        selectedIndex = -1;
        scrollOffset = 0;
        handler.setActiveTab(activeTab);
    }

    @Override
    protected void init() {
        super.init();
        // Tab buttons
        addDrawableChild(ButtonWidget.builder(Text.literal("Armas"), btn -> {
            activeTab = 0;
            refreshRecipes();
        }).dimensions(x + 5, y + 3, 44, 12).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Balas"), btn -> {
            activeTab = 1;
            refreshRecipes();
        }).dimensions(x + 51, y + 3, 44, 12).build());

        // Scroll buttons
        addDrawableChild(ButtonWidget.builder(Text.literal("▲"), btn -> {
            if (scrollOffset > 0) scrollOffset--;
        }).dimensions(x + LIST_X + LIST_W - 12, y + LIST_Y, 12, 10).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("▼"), btn -> {
            if (scrollOffset + MAX_VISIBLE < currentRecipes.size()) scrollOffset++;
        }).dimensions(x + LIST_X + LIST_W - 12, y + LIST_Y + 10 + MAX_VISIBLE * LIST_ENTRY_H - 10, 12, 10).build());
    }

    @Override
    protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
        // Draw grey background
        context.fill(x, y, x + backgroundWidth, y + backgroundHeight, 0xFF8B8B8B);
        context.fill(x + 1, y + 1, x + backgroundWidth - 1, y + backgroundHeight - 1, 0xFFC6C6C6);

        // Recipe list panel background
        context.fill(x + LIST_X, y + LIST_Y, x + LIST_X + LIST_W, y + LIST_Y + MAX_VISIBLE * LIST_ENTRY_H, 0xFF555555);

        // Draw visible recipes
        for (int i = 0; i < MAX_VISIBLE; i++) {
            int idx = i + scrollOffset;
            if (idx >= currentRecipes.size()) break;
            WeaponRecipe recipe = currentRecipes.get(idx);

            int entryX = x + LIST_X;
            int entryY = y + LIST_Y + i * LIST_ENTRY_H;
            int bg = (idx == selectedIndex) ? 0xFF4A90D9 : 0xFF777777;
            context.fill(entryX, entryY, entryX + LIST_W - 14, entryY + LIST_ENTRY_H - 1, bg);

            // Draw item icon
            context.drawItem(recipe.output(), entryX + 1, entryY + 2);
            // Draw name
            context.drawText(textRenderer, Text.literal(recipe.displayName()), entryX + 20, entryY + 6, 0xFFFFFF, false);
        }

        // Draw crafting area header
        context.drawText(textRenderer, Text.literal("Crafteo:"), x + 104, y + 15, 0x333333, false);

        // Draw selected recipe ingredients
        if (selectedIndex >= 0 && selectedIndex < currentRecipes.size()) {
            WeaponRecipe recipe = currentRecipes.get(selectedIndex);
            List<WeaponRecipe.Ingredient> ings = recipe.ingredients();

            // Draw input slots and labels
            int slotBaseX = x + 100;
            int slotBaseY = y + 25;
            for (int i = 0; i < ings.size(); i++) {
                WeaponRecipe.Ingredient ing = ings.get(i);
                int slotX = slotBaseX + (i % 2) * 22;
                int slotY = slotBaseY + (i / 2) * 22;

                // Slot background
                context.fill(slotX - 1, slotY - 1, slotX + 17, slotY + 17, 0xFF888888);
                context.fill(slotX, slotY, slotX + 16, slotY + 16, 0xFF555555);

                // Required item icon
                context.drawItem(new ItemStack(ing.item(), ing.count()), slotX, slotY);
                // Count label
                context.drawText(textRenderer, Text.literal("x" + ing.count()), slotX, slotY + 10, 0xFFFFFF, true);
            }

            // Arrow
            context.drawText(textRenderer, Text.literal("→"), x + 148, y + 32, 0x333333, false);

            // Output slot
            int outX = x + 158;
            int outY = y + 27;
            context.fill(outX - 1, outY - 1, outX + 17, outY + 17, 0xFFFFAA00);
            context.fill(outX, outY, outX + 16, outY + 16, 0xFF555555);
            context.drawItem(recipe.output(), outX, outY);
            context.drawText(textRenderer, Text.literal("x" + recipe.output().getCount()), outX, outY + 10, 0xFFFFFF, true);

            // Ingredient list text
            int textY = y + 75;
            context.drawText(textRenderer, Text.literal("Necesitas:"), x + 100, textY, 0x222222, false);
            textY += 10;
            for (WeaponRecipe.Ingredient ing : ings) {
                String name = ing.item().getName().getString();
                context.drawText(textRenderer, Text.literal("• " + name + " x" + ing.count()), x + 100, textY, 0x111111, false);
                textY += 9;
            }
        }

        // Player inventory label
        context.drawText(textRenderer, Text.literal("Inventario"), x + 8, y + 72, 0x333333, false);

        // Divider
        context.fill(x + 5, y + 80, x + 190, y + 81, 0xFF777777);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Check recipe list click
        int relX = (int) mouseX - x;
        int relY = (int) mouseY - y;
        if (relX >= LIST_X && relX < LIST_X + LIST_W - 14
                && relY >= LIST_Y && relY < LIST_Y + MAX_VISIBLE * LIST_ENTRY_H) {
            int clicked = (relY - LIST_Y) / LIST_ENTRY_H + scrollOffset;
            if (clicked >= 0 && clicked < currentRecipes.size()) {
                selectedIndex = clicked;
                handler.setSelectedRecipe(currentRecipes.get(clicked));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (amount < 0 && scrollOffset + MAX_VISIBLE < currentRecipes.size()) scrollOffset++;
        else if (amount > 0 && scrollOffset > 0) scrollOffset--;
        return true;
    }

    @Override
    protected void drawForeground(DrawContext context, int mouseX, int mouseY) {
        // Suppress default title drawing
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        super.render(context, mouseX, mouseY, delta);
        drawMouseoverTooltip(context, mouseX, mouseY);
    }
}
