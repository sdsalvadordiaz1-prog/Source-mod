package com.weaponsmod.recipe;

public class ModRecipes {
    public static void registerRecipes() {
        // WeaponRecipeManager uses a static list — no additional registration needed.
        // The Weapon Crafting Table handles all recipe logic internally.
    }
}
