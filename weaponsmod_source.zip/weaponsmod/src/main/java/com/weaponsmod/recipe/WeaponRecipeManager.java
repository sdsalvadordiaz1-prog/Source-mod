package com.weaponsmod.recipe;

import com.weaponsmod.item.ModItems;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * All weapon crafting table recipes.
 *
 * ──────────────────────────────────────────────────────────────────
 *  WEAPON RECIPES  (ingredients shown as: [item x count])
 * ──────────────────────────────────────────────────────────────────
 *  PISTOLA         2 slots: [Madera x5] [Carbón x20]
 *  ESCOPETA        3 slots: [Madera x8] [Hierro x3] [Carbón x15]
 *  SNIPER          3 slots: [Hierro x6] [Redstone x4] [Flecha x1]
 *  LANZAGRANADAS   4 slots: [Hierro x8] [Pólvora x4] [Madera x3] [Roca x4]
 *  AK-47           4 slots: [Hierro x10] [Madera x4] [Carbón x10] [Redstone x2]
 *  METRALLETA      4 slots: [Hierro x16] [Redstone x6] [Madera x6] [Pólvora x3]
 *
 * ──────────────────────────────────────────────────────────────────
 *  AMMO RECIPES
 * ──────────────────────────────────────────────────────────────────
 *  BALA PISTOLA    2 slots: [Hierro x2] [Pólvora x1]  → 8 balas
 *  CARTUCHO ESCOPETA 2 slots: [Hierro x3] [Pólvora x2] → 4 cartuchos
 *  BALA SNIPER     2 slots: [Hierro x4] [Pólvora x1]  → 4 balas
 *  GRANADA         3 slots: [Hierro x4] [Pólvora x4] [Pedernal x1] → 1 granada
 *  BALA RIFLE      2 slots: [Hierro x2] [Pólvora x1]  → 16 balas
 * ──────────────────────────────────────────────────────────────────
 */
public class WeaponRecipeManager {

    private static final List<WeaponRecipe> RECIPES = new ArrayList<>();

    static {
        // ── WEAPONS ──────────────────────────────────────────────────────────
        RECIPES.add(new WeaponRecipe(
                "pistol",
                "Pistola",
                List.of(
                        new WeaponRecipe.Ingredient(Items.OAK_PLANKS, 5),
                        new WeaponRecipe.Ingredient(Items.COAL, 20)
                ),
                new ItemStack(ModItems.PISTOL, 1),
                WeaponRecipe.RecipeCategory.WEAPON
        ));

        RECIPES.add(new WeaponRecipe(
                "shotgun",
                "Escopeta",
                List.of(
                        new WeaponRecipe.Ingredient(Items.OAK_PLANKS, 8),
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 3),
                        new WeaponRecipe.Ingredient(Items.COAL, 15)
                ),
                new ItemStack(ModItems.SHOTGUN, 1),
                WeaponRecipe.RecipeCategory.WEAPON
        ));

        RECIPES.add(new WeaponRecipe(
                "sniper",
                "Sniper",
                List.of(
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 6),
                        new WeaponRecipe.Ingredient(Items.REDSTONE, 4),
                        new WeaponRecipe.Ingredient(Items.ARROW, 1)
                ),
                new ItemStack(ModItems.SNIPER, 1),
                WeaponRecipe.RecipeCategory.WEAPON
        ));

        RECIPES.add(new WeaponRecipe(
                "grenade_launcher",
                "Lanzagranadas",
                List.of(
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 8),
                        new WeaponRecipe.Ingredient(Items.GUNPOWDER, 4),
                        new WeaponRecipe.Ingredient(Items.OAK_PLANKS, 3),
                        new WeaponRecipe.Ingredient(Items.STONE, 4)
                ),
                new ItemStack(ModItems.GRENADE_LAUNCHER, 1),
                WeaponRecipe.RecipeCategory.WEAPON
        ));

        RECIPES.add(new WeaponRecipe(
                "ak47",
                "AK-47",
                List.of(
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 10),
                        new WeaponRecipe.Ingredient(Items.OAK_PLANKS, 4),
                        new WeaponRecipe.Ingredient(Items.COAL, 10),
                        new WeaponRecipe.Ingredient(Items.REDSTONE, 2)
                ),
                new ItemStack(ModItems.AK47, 1),
                WeaponRecipe.RecipeCategory.WEAPON
        ));

        RECIPES.add(new WeaponRecipe(
                "minigun",
                "Metralleta",
                List.of(
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 16),
                        new WeaponRecipe.Ingredient(Items.REDSTONE, 6),
                        new WeaponRecipe.Ingredient(Items.OAK_PLANKS, 6),
                        new WeaponRecipe.Ingredient(Items.GUNPOWDER, 3)
                ),
                new ItemStack(ModItems.MINIGUN, 1),
                WeaponRecipe.RecipeCategory.WEAPON
        ));

        // ── AMMO ─────────────────────────────────────────────────────────────
        RECIPES.add(new WeaponRecipe(
                "pistol_bullet",
                "Bala Pistola x8",
                List.of(
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 2),
                        new WeaponRecipe.Ingredient(Items.GUNPOWDER, 1)
                ),
                new ItemStack(ModItems.PISTOL_BULLET, 8),
                WeaponRecipe.RecipeCategory.AMMO
        ));

        RECIPES.add(new WeaponRecipe(
                "shotgun_shell",
                "Cartucho Escopeta x4",
                List.of(
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 3),
                        new WeaponRecipe.Ingredient(Items.GUNPOWDER, 2)
                ),
                new ItemStack(ModItems.SHOTGUN_SHELL, 4),
                WeaponRecipe.RecipeCategory.AMMO
        ));

        RECIPES.add(new WeaponRecipe(
                "sniper_bullet",
                "Bala Sniper x4",
                List.of(
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 4),
                        new WeaponRecipe.Ingredient(Items.GUNPOWDER, 1)
                ),
                new ItemStack(ModItems.SNIPER_BULLET, 4),
                WeaponRecipe.RecipeCategory.AMMO
        ));

        RECIPES.add(new WeaponRecipe(
                "grenade",
                "Granada x1",
                List.of(
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 4),
                        new WeaponRecipe.Ingredient(Items.GUNPOWDER, 4),
                        new WeaponRecipe.Ingredient(Items.FLINT, 1)
                ),
                new ItemStack(ModItems.GRENADE, 1),
                WeaponRecipe.RecipeCategory.AMMO
        ));

        RECIPES.add(new WeaponRecipe(
                "rifle_bullet",
                "Bala Rifle x16",
                List.of(
                        new WeaponRecipe.Ingredient(Items.IRON_INGOT, 2),
                        new WeaponRecipe.Ingredient(Items.GUNPOWDER, 1)
                ),
                new ItemStack(ModItems.RIFLE_BULLET, 16),
                WeaponRecipe.RecipeCategory.AMMO
        ));
    }

    public static List<WeaponRecipe> getAll() {
        return RECIPES;
    }

    public static List<WeaponRecipe> getByCategory(WeaponRecipe.RecipeCategory category) {
        return RECIPES.stream().filter(r -> r.category() == category).toList();
    }
}
