package com.weaponsmod.recipe;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import java.util.List;

/**
 * Represents a recipe in the Weapon Crafting Table.
 * Each recipe has a variable number of ingredients (1-4) and an output.
 */
public record WeaponRecipe(
        String id,
        String displayName,
        List<Ingredient> ingredients,
        ItemStack output,
        RecipeCategory category
) {
    public record Ingredient(Item item, int count) {}

    public enum RecipeCategory {
        WEAPON, AMMO
    }
}
