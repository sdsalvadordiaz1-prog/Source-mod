package com.weaponsmod.block;

import com.weaponsmod.WeaponsMod;
import com.weaponsmod.item.ModItems;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.MapColor;
import net.minecraft.block.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlocks {

    public static final WeaponCraftingTableBlock WEAPON_CRAFTING_TABLE = new WeaponCraftingTableBlock(
            FabricBlockSettings.of(Material.METAL)
                    .mapColor(MapColor.IRON_GRAY)
                    .strength(3.5f, 6.0f)
                    .requiresTool()
    );

    public static void registerBlocks() {
        // Register block
        Registry.register(Registries.BLOCK,
                new Identifier(WeaponsMod.MOD_ID, "weapon_crafting_table"),
                WEAPON_CRAFTING_TABLE);

        // Register block item
        Registry.register(Registries.ITEM,
                new Identifier(WeaponsMod.MOD_ID, "weapon_crafting_table"),
                new BlockItem(WEAPON_CRAFTING_TABLE, new FabricItemSettings()));

        // Add to weapons group
        ItemGroupEvents.modifyEntriesEvent(ModItems.WEAPONS_GROUP_KEY).register(entries -> {
            entries.addFirst(new net.minecraft.item.ItemStack(WEAPON_CRAFTING_TABLE));
        });
    }
}
