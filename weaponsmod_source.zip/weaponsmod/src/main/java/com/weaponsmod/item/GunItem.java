package com.weaponsmod.item;

import com.weaponsmod.WeaponsMod;
import com.weaponsmod.entity.BulletEntity;
import com.weaponsmod.entity.GrenadeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import net.minecraft.registry.Registries;

public class GunItem extends Item {

    private final GunType gunType;
    private static final String COOLDOWN_KEY = "Cooldown";

    public GunItem(Settings settings, GunType gunType) {
        super(settings);
        this.gunType = gunType;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);

        if (world.isClient) return TypedActionResult.pass(stack);

        // Check cooldown via item damage as simple timer (use NBT for real cooldown)
        int lastUsed = stack.hasNbt() && stack.getNbt().contains(COOLDOWN_KEY)
                ? stack.getNbt().getInt(COOLDOWN_KEY) : 0;
        long currentTick = world.getTime();
        if (currentTick - lastUsed < gunType.fireCooldown) {
            return TypedActionResult.fail(stack);
        }

        // Find ammo
        Identifier ammoId = new Identifier(WeaponsMod.MOD_ID, gunType.ammoId);
        Item ammoItem = Registries.ITEM.get(ammoId);
        int ammoSlot = findAmmo(player, ammoItem);

        if (ammoSlot == -1) {
            if (!world.isClient) {
                player.sendMessage(Text.literal("§cNo tienes balas para " + gunType.displayName + "!"), true);
            }
            return TypedActionResult.fail(stack);
        }

        // Consume ammo (not in creative)
        if (!player.isCreative()) {
            player.getInventory().getStack(ammoSlot).decrement(1);
        }

        // Set cooldown
        stack.getOrCreateNbt().putLong(COOLDOWN_KEY, currentTick);

        // Play sound
        playGunSound(world, player);

        // Fire projectiles
        for (int i = 0; i < gunType.pellets; i++) {
            spawnProjectile(world, player, i);
        }

        return TypedActionResult.success(stack);
    }

    private void playGunSound(World world, PlayerEntity player) {
        switch (gunType) {
            case SHOTGUN -> world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6f, 1.5f);
            case SNIPER -> world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.5f, 0.5f);
            case GRENADE_LAUNCHER -> world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, SoundCategory.PLAYERS, 1.0f, 0.8f);
            case MINIGUN, AK47 -> world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 0.8f, 1.8f);
            default -> world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0f, 1.2f);
        }
    }

    private void spawnProjectile(World world, PlayerEntity player, int pelletIndex) {
        if (gunType == GunType.GRENADE_LAUNCHER) {
            GrenadeEntity grenade = new GrenadeEntity(world, player);
            grenade.setVelocity(player, player.getPitch(), player.getYaw(), 0.0f, 1.5f, 1.0f);
            world.spawnEntity(grenade);
        } else {
            BulletEntity bullet = new BulletEntity(world, player, gunType);
            float spread = 0.0f;
            if (gunType == GunType.SHOTGUN) spread = 0.15f;
            else if (gunType == GunType.MINIGUN) spread = 0.05f;
            else if (gunType == GunType.AK47) spread = 0.03f;

            float spreadX = (pelletIndex == 0) ? 0 : (world.random.nextFloat() - 0.5f) * spread;
            float spreadY = (pelletIndex == 0) ? 0 : (world.random.nextFloat() - 0.5f) * spread;

            bullet.setVelocity(player, player.getPitch() + spreadY, player.getYaw() + spreadX, 0.0f, 3.5f, spread);
            world.spawnEntity(bullet);
        }
    }

    private int findAmmo(PlayerEntity player, Item ammoItem) {
        for (int i = 0; i < player.getInventory().size(); i++) {
            if (player.getInventory().getStack(i).getItem() == ammoItem) {
                return i;
            }
        }
        return -1;
    }

    public GunType getGunType() {
        return gunType;
    }
}
