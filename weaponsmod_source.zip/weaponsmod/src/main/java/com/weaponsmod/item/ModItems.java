package com.weaponsmod.item;

import com.weaponsmod.WeaponsMod;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItems {

    // === WEAPONS ===
    public static final Item PISTOL = new GunItem(new FabricItemSettings().maxCount(1).maxDamage(100), GunType.PISTOL);
    public static final Item SHOTGUN = new GunItem(new FabricItemSettings().maxCount(1).maxDamage(80), GunType.SHOTGUN);
    public static final Item SNIPER = new GunItem(new FabricItemSettings().maxCount(1).maxDamage(60), GunType.SNIPER);
    public static final Item GRENADE_LAUNCHER = new GunItem(new FabricItemSettings().maxCount(1).maxDamage(40), GunType.GRENADE_LAUNCHER);
    public static final Item AK47 = new GunItem(new FabricItemSettings().maxCount(1).maxDamage(150), GunType.AK47);
    public static final Item MINIGUN = new GunItem(new FabricItemSettings().maxCount(1).maxDamage(300), GunType.MINIGUN);

    // === AMMO ===
    public static final Item PISTOL_BULLET = new Item(new FabricItemSettings().maxCount(64));
    public static final Item SHOTGUN_SHELL = new Item(new FabricItemSettings().maxCount(64));
    public static final Item SNIPER_BULLET = new Item(new FabricItemSettings().maxCount(32));
    public static final Item GRENADE = new Item(new FabricItemSettings().maxCount(16));
    public static final Item RIFLE_BULLET = new Item(new FabricItemSettings().maxCount(64));

    // === ITEM GROUP ===
    public static final RegistryKey<ItemGroup> WEAPONS_GROUP_KEY = RegistryKey.of(
            Registries.ITEM_GROUP.getKey(),
            new Identifier(WeaponsMod.MOD_ID, "weapons")
    );

    public static void registerItems() {
        // Weapons
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "pistol"), PISTOL);
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "shotgun"), SHOTGUN);
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "sniper"), SNIPER);
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "grenade_launcher"), GRENADE_LAUNCHER);
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "ak47"), AK47);
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "minigun"), MINIGUN);

        // Ammo
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "pistol_bullet"), PISTOL_BULLET);
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "shotgun_shell"), SHOTGUN_SHELL);
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "sniper_bullet"), SNIPER_BULLET);
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "grenade"), GRENADE);
        Registry.register(Registries.ITEM, new Identifier(WeaponsMod.MOD_ID, "rifle_bullet"), RIFLE_BULLET);

        // Register Item Group
        Registry.register(Registries.ITEM_GROUP, WEAPONS_GROUP_KEY, FabricItemGroup.builder()
                .icon(() -> new ItemStack(PISTOL))
                .displayName(Text.translatable("itemGroup.weaponsmod.weapons"))
                .build());

        ItemGroupEvents.modifyEntriesEvent(WEAPONS_GROUP_KEY).register(entries -> {
            // Weapons tab
            entries.add(PISTOL);
            entries.add(SHOTGUN);
            entries.add(SNIPER);
            entries.add(GRENADE_LAUNCHER);
            entries.add(AK47);
            entries.add(MINIGUN);
            // Ammo
            entries.add(PISTOL_BULLET);
            entries.add(SHOTGUN_SHELL);
            entries.add(SNIPER_BULLET);
            entries.add(GRENADE);
            entries.add(RIFLE_BULLET);
        });
    }
}
