package com.weaponsmod.item;

public enum GunType {
    PISTOL(
        "Pistola",
        7.0f,       // damage
        20,         // fire rate (ticks between shots)
        1,          // pellets
        false,      // explosive
        "pistol_bullet"
    ),
    SHOTGUN(
        "Escopeta",
        4.0f,
        30,
        6,          // 6 pellets spread
        false,
        "shotgun_shell"
    ),
    SNIPER(
        "Sniper",
        25.0f,
        60,         // slow fire rate
        1,
        false,
        "sniper_bullet"
    ),
    GRENADE_LAUNCHER(
        "Lanzagranadas",
        20.0f,
        80,
        1,
        true,       // explosive
        "grenade"
    ),
    AK47(
        "AK-47",
        6.0f,
        5,          // very fast
        1,
        false,
        "rifle_bullet"
    ),
    MINIGUN(
        "Metralleta",
        4.0f,
        2,          // insanely fast
        1,
        false,
        "rifle_bullet"
    );

    public final String displayName;
    public final float damage;
    public final int fireCooldown;   // ticks
    public final int pellets;
    public final boolean explosive;
    public final String ammoId;

    GunType(String displayName, float damage, int fireCooldown, int pellets, boolean explosive, String ammoId) {
        this.displayName = displayName;
        this.damage = damage;
        this.fireCooldown = fireCooldown;
        this.pellets = pellets;
        this.explosive = explosive;
        this.ammoId = ammoId;
    }
}
