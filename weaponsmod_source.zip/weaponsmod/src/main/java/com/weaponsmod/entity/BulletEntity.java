package com.weaponsmod.entity;

import com.weaponsmod.item.GunType;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

public class BulletEntity extends ThrownItemEntity {

    private final GunType gunType;

    public BulletEntity(World world, LivingEntity owner, GunType gunType) {
        super(ModEntities.BULLET, owner, world);
        this.gunType = gunType;
    }

    public BulletEntity(World world) {
        super(ModEntities.BULLET, world);
        this.gunType = GunType.PISTOL; // default
    }

    @Override
    protected Item getDefaultItem() {
        return Items.ARROW;
    }

    @Override
    protected void onCollision(HitResult hitResult) {
        if (hitResult.getType() == HitResult.Type.ENTITY) {
            onEntityHit((EntityHitResult) hitResult);
        }
        if (!this.getWorld().isClient) {
            this.discard();
        }
    }

    @Override
    protected void onEntityHit(EntityHitResult entityHitResult) {
        if (!this.getWorld().isClient) {
            entityHitResult.getEntity().damage(
                    this.getWorld().getDamageSources().thrown(this, this.getOwner()),
                    gunType.damage
            );
        }
    }

    @Override
    public void tick() {
        super.tick();
        // Bullets travel fast and despawn quickly
        if (this.age > 60) {
            this.discard();
        }
    }
}
