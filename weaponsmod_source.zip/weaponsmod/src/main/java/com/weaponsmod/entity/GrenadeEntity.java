package com.weaponsmod.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;

public class GrenadeEntity extends ThrownItemEntity {

    public GrenadeEntity(World world, LivingEntity owner) {
        super(ModEntities.GRENADE, owner, world);
    }

    public GrenadeEntity(World world) {
        super(ModEntities.GRENADE, world);
    }

    @Override
    protected Item getDefaultItem() {
        return Items.FIRE_CHARGE;
    }

    @Override
    protected void onCollision(HitResult hitResult) {
        if (!this.getWorld().isClient) {
            // Create explosion on impact
            this.getWorld().createExplosion(
                    this,
                    this.getX(), this.getY(), this.getZ(),
                    4.0f,   // explosion radius
                    false,  // no fire
                    World.ExplosionSourceType.MOB
            );
            this.discard();
        }
    }

    @Override
    public void tick() {
        super.tick();
        // Grenade explodes after 3 seconds if it hasn't hit anything
        if (this.age > 60) {
            if (!this.getWorld().isClient) {
                this.getWorld().createExplosion(
                        this,
                        this.getX(), this.getY(), this.getZ(),
                        4.0f,
                        false,
                        World.ExplosionSourceType.MOB
                );
                this.discard();
            }
        }
    }
}
