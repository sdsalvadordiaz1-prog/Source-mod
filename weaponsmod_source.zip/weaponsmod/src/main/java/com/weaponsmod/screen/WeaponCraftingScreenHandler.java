package com.weaponsmod.screen;

import com.weaponsmod.item.ModItems;
import com.weaponsmod.recipe.WeaponRecipe;
import com.weaponsmod.recipe.WeaponRecipeManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.slot.Slot;

import java.util.List;

public class WeaponCraftingScreenHandler extends ScreenHandler {

    private final ScreenHandlerContext context;
    private final SimpleInventory craftingInventory;
    private WeaponRecipe selectedRecipe;
    private int activeTab = 0; // 0 = weapons, 1 = ammo

    // Crafting slots (max 4 for any recipe)
    public static final int CRAFT_SLOT_COUNT = 4;

    public WeaponCraftingScreenHandler(int syncId, PlayerInventory playerInventory, ScreenHandlerContext context) {
        super(ModScreenHandlers.WEAPON_CRAFTING, syncId);
        this.context = context;
        this.craftingInventory = new SimpleInventory(CRAFT_SLOT_COUNT + 1); // +1 output

        // Add crafting input slots (displayed dynamically on client)
        // Slot positions: arranged vertically, 2 columns max
        // Slot 0 (x=30, y=20)
        this.addSlot(new Slot(craftingInventory, 0, 30, 20));
        // Slot 1 (x=30, y=40)
        this.addSlot(new Slot(craftingInventory, 1, 30, 40));
        // Slot 2 (x=50, y=20)
        this.addSlot(new Slot(craftingInventory, 2, 50, 20));
        // Slot 3 (x=50, y=40)
        this.addSlot(new Slot(craftingInventory, 3, 50, 40));

        // Output slot
        this.addSlot(new Slot(craftingInventory, 4, 124, 35) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return false;
            }
            @Override
            public void onTakeItem(PlayerEntity player, ItemStack stack) {
                consumeIngredients(player);
                super.onTakeItem(player, stack);
                updateOutput();
            }
        });

        // Player inventory (27 slots)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        // Hotbar (9 slots)
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
        }
    }

    public void setSelectedRecipe(WeaponRecipe recipe) {
        this.selectedRecipe = recipe;
        // Clear crafting slots
        for (int i = 0; i < CRAFT_SLOT_COUNT; i++) {
            craftingInventory.setStack(i, ItemStack.EMPTY);
        }
        updateOutput();
    }

    public void updateOutput() {
        if (selectedRecipe == null) {
            craftingInventory.setStack(4, ItemStack.EMPTY);
            return;
        }
        // Check if ingredients are present
        if (hasIngredients()) {
            craftingInventory.setStack(4, selectedRecipe.output().copy());
        } else {
            craftingInventory.setStack(4, ItemStack.EMPTY);
        }
    }

    private boolean hasIngredients() {
        if (selectedRecipe == null) return false;
        List<WeaponRecipe.Ingredient> required = selectedRecipe.ingredients();
        for (int i = 0; i < required.size(); i++) {
            ItemStack slot = craftingInventory.getStack(i);
            WeaponRecipe.Ingredient ing = required.get(i);
            if (slot.getItem() != ing.item() || slot.getCount() < ing.count()) {
                return false;
            }
        }
        return true;
    }

    private void consumeIngredients() {
        if (selectedRecipe == null) return;
        for (int i = 0; i < selectedRecipe.ingredients().size(); i++) {
            craftingInventory.getStack(i).decrement(selectedRecipe.ingredients().get(i).count());
        }
        updateOutput();
    }

    private void consumeIngredients(PlayerEntity player) {
        consumeIngredients();
    }

    public int getActiveTab() { return activeTab; }
    public void setActiveTab(int tab) {
        this.activeTab = tab;
        this.selectedRecipe = null;
        for (int i = 0; i < CRAFT_SLOT_COUNT; i++) {
            craftingInventory.setStack(i, ItemStack.EMPTY);
        }
        craftingInventory.setStack(4, ItemStack.EMPTY);
    }

    public WeaponRecipe getSelectedRecipe() { return selectedRecipe; }
    public SimpleInventory getCraftingInventory() { return craftingInventory; }

    @Override
    public ItemStack quickMove(PlayerEntity player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return context.get((world, pos) ->
                world.getBlockState(pos).getBlock() instanceof com.weaponsmod.block.WeaponCraftingTableBlock
                        && player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) < 64.0,
                true
        );
    }

    @Override
    public void onClosed(PlayerEntity player) {
        super.onClosed(player);
        context.run((world, pos) -> dropInventory(player, craftingInventory));
    }
}
