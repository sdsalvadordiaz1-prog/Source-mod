package com.weaponsmod.item;

public enum GunType {
    PISTOL(
        "Pistola",
        7.0f,
        20,
        1,
        false,
        "pistol_bullet",
        8   // magazine size
    ),
    SHOTGUN(
        "Escopeta",
        4.0f,
        30,
        6,
        false,
        "shotgun_shell",
        2
    ),
    SNIPER(
        "Sniper",
        25.0f,
        60,
        1,
        false,
        "sniper_bullet",
        5
    ),
    GRENADE_LAUNCHER(
        "Lanzagranadas",
        20.0f,
        80,
        1,
        true,
        "grenade",
        1
    ),
    AK47(
        "AK-47",
        6.0f,
        5,
        1,
        false,
        "rifle_bullet",
        30
    ),
    MINIGUN(
        "Metralleta",
        4.0f,
        2,
        1,
        false,
        "rifle_bullet",
        100
    );

    public final String displayName;
    public final float damage;
    public final int fireCooldown;
    public final int pellets;
    public final boolean explosive;
    public final String ammoId;
    public final int magazineSize;

    GunType(String displayName, float damage, int fireCooldown, int pellets, boolean explosive, String ammoId, int magazineSize) {
        this.displayName = displayName;
        this.damage = damage;
        this.fireCooldown = fireCooldown;
        this.pellets = pellets;
        this.explosive = explosive;
        this.ammoId = ammoId;
        this.magazineSize = magazineSize;
    }
}
