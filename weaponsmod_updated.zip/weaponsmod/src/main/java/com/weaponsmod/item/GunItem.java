package com.weaponsmod.item;

import com.weaponsmod.WeaponsMod;
import com.weaponsmod.entity.BulletEntity;
import com.weaponsmod.entity.GrenadeEntity;
import com.weaponsmod.sound.ModSounds;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import net.minecraft.registry.Registries;

import java.util.List;

public class GunItem extends Item {

    private final GunType gunType;
    private static final String COOLDOWN_KEY = "Cooldown";
    private static final String AMMO_KEY = "LoadedAmmo";
    private static final String RELOADING_KEY = "ReloadTick";

    public GunItem(Settings settings, GunType gunType) {
        super(settings);
        this.gunType = gunType;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);

        if (world.isClient) return TypedActionResult.pass(stack);

        NbtCompound nbt = stack.getOrCreateNbt();

        // Check cooldown
        int lastUsed = nbt.contains(COOLDOWN_KEY) ? nbt.getInt(COOLDOWN_KEY) : 0;
        long currentTick = world.getTime();
        if (currentTick - lastUsed < gunType.fireCooldown) {
            return TypedActionResult.fail(stack);
        }

        // Check loaded ammo
        int loadedAmmo = nbt.contains(AMMO_KEY) ? nbt.getInt(AMMO_KEY) : 0;
        if (loadedAmmo <= 0) {
            player.sendMessage(Text.literal("§cRecarga con M! " + gunType.displayName + ": 0/" + gunType.magazineSize), true);
            world.playSound(null, player.getBlockPos(), ModSounds.EMPTY_CLICK, SoundCategory.PLAYERS, 1.0f, 1.0f);
            return TypedActionResult.fail(stack);
        }

        // Consume loaded ammo
        nbt.putInt(AMMO_KEY, loadedAmmo - 1);
        // Set cooldown
        nbt.putInt(COOLDOWN_KEY, (int) currentTick);

        // Play gun-specific sound
        playGunSound(world, player);

        // Muzzle flash particle effect (server side, clients see it)
        if (world instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.FLASH,
                    player.getX() + player.getRotationVector().x,
                    player.getEyeY(),
                    player.getZ() + player.getRotationVector().z,
                    1, 0, 0, 0, 0);
            serverWorld.spawnParticles(ParticleTypes.SMOKE,
                    player.getX(), player.getEyeY(), player.getZ(),
                    5, 0.1, 0.1, 0.1, 0.02);
        }

        // Apply speed effect when shooting (recoil visual)
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 3, 0, false, false));

        // Fire projectiles
        for (int i = 0; i < gunType.pellets; i++) {
            spawnProjectile(world, player, i);
        }

        return TypedActionResult.success(stack);
    }

    public boolean reload(World world, PlayerEntity player, ItemStack stack) {
        if (world.isClient) return false;

        NbtCompound nbt = stack.getOrCreateNbt();
        int loadedAmmo = nbt.contains(AMMO_KEY) ? nbt.getInt(AMMO_KEY) : 0;

        if (loadedAmmo >= gunType.magazineSize) {
            player.sendMessage(Text.literal("§aCargador lleno!"), true);
            return false;
        }

        // Find ammo in inventory
        Identifier ammoId = new Identifier(WeaponsMod.MOD_ID, gunType.ammoId);
        Item ammoItem = Registries.ITEM.get(ammoId);

        int needed = gunType.magazineSize - loadedAmmo;
        int found = 0;

        for (int i = 0; i < player.getInventory().size() && found < needed; i++) {
            ItemStack invStack = player.getInventory().getStack(i);
            if (invStack.getItem() == ammoItem) {
                int take = Math.min(invStack.getCount(), needed - found);
                if (!player.isCreative()) {
                    invStack.decrement(take);
                }
                found += take;
            }
        }

        if (found == 0) {
            player.sendMessage(Text.literal("§cNo tienes " + ammoItem.getName().getString() + "!"), true);
            return false;
        }

        nbt.putInt(AMMO_KEY, loadedAmmo + found);
        world.playSound(null, player.getBlockPos(), ModSounds.RELOAD, SoundCategory.PLAYERS, 1.0f, 1.0f);
        player.sendMessage(Text.literal("§aRecargado! " + (loadedAmmo + found) + "/" + gunType.magazineSize), true);
        return true;
    }

    private void playGunSound(World world, PlayerEntity player) {
        switch (gunType) {
            case SHOTGUN -> world.playSound(null, player.getBlockPos(),
                    ModSounds.SHOTGUN_FIRE, SoundCategory.PLAYERS, 1.0f, 1.0f);
            case SNIPER -> world.playSound(null, player.getBlockPos(),
                    ModSounds.SNIPER_FIRE, SoundCategory.PLAYERS, 1.5f, 1.0f);
            case GRENADE_LAUNCHER -> world.playSound(null, player.getBlockPos(),
                    ModSounds.GRENADE_LAUNCH, SoundCategory.PLAYERS, 1.0f, 1.0f);
            case MINIGUN -> world.playSound(null, player.getBlockPos(),
                    ModSounds.MINIGUN_FIRE, SoundCategory.PLAYERS, 0.8f, 1.0f);
            case AK47 -> world.playSound(null, player.getBlockPos(),
                    ModSounds.AK47_FIRE, SoundCategory.PLAYERS, 1.0f, 1.0f);
            default -> world.playSound(null, player.getBlockPos(),
                    ModSounds.PISTOL_FIRE, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
    }

    private void spawnProjectile(World world, PlayerEntity player, int pelletIndex) {
        if (gunType == GunType.GRENADE_LAUNCHER) {
            GrenadeEntity grenade = new GrenadeEntity(world, player);
            grenade.setVelocity(player, player.getPitch(), player.getYaw(), 0.0f, 1.5f, 1.0f);
            world.spawnEntity(grenade);
        } else {
            BulletEntity bullet = new BulletEntity(world, player, gunType);
            float spread = 0.0f;
            if (gunType == GunType.SHOTGUN) spread = 0.15f;
            else if (gunType == GunType.MINIGUN) spread = 0.05f;
            else if (gunType == GunType.AK47) spread = 0.03f;

            float spreadX = (pelletIndex == 0) ? 0 : (world.random.nextFloat() - 0.5f) * spread;
            float spreadY = (pelletIndex == 0) ? 0 : (world.random.nextFloat() - 0.5f) * spread;
            bullet.setVelocity(player, player.getPitch() + spreadY, player.getYaw() + spreadX, 0.0f, 3.5f, spread);
            world.spawnEntity(bullet);
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        NbtCompound nbt = stack.getNbt();
        int loaded = (nbt != null && nbt.contains(AMMO_KEY)) ? nbt.getInt(AMMO_KEY) : 0;
        tooltip.add(Text.literal("§7Balas: §f" + loaded + "/" + gunType.magazineSize));
        tooltip.add(Text.literal("§7Daño: §c" + gunType.damage));
        tooltip.add(Text.literal("§7[M] para recargar"));
        if (gunType == GunType.SNIPER) {
            tooltip.add(Text.literal("§7[Shift+Clic] para zoom"));
        }
    }

    public GunType getGunType() {
        return gunType;
    }

    public int getLoadedAmmo(ItemStack stack) {
        NbtCompound nbt = stack.getNbt();
        return (nbt != null && nbt.contains(AMMO_KEY)) ? nbt.getInt(AMMO_KEY) : 0;
    }
}
