package com.weaponsmod.network;

import com.weaponsmod.WeaponsMod;
import com.weaponsmod.item.GunItem;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

public class ReloadPacket {

    public static final Identifier ID = new Identifier(WeaponsMod.MOD_ID, "reload");

    public static PacketByteBuf create() {
        return PacketByteBufs.empty();
    }

    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(ID, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                ItemStack held = player.getMainHandStack();
                if (held.getItem() instanceof GunItem gun) {
                    gun.reload(player.getWorld(), player, held);
                }
            });
        });
    }
}
