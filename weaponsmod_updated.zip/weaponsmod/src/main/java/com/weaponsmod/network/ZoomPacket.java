package com.weaponsmod.network;

import com.weaponsmod.WeaponsMod;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

public class ZoomPacket {
    public static final Identifier ID = new Identifier(WeaponsMod.MOD_ID, "zoom");

    public static PacketByteBuf create(boolean zoomed) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeBoolean(zoomed);
        return buf;
    }

    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(ID, (server, player, handler, buf, responseSender) -> {
            boolean zooming = buf.readBoolean();
            server.execute(() -> {
                // Server can store zoom state in NBT if needed for anti-cheat
                // For now just acknowledge
            });
        });
    }
}
