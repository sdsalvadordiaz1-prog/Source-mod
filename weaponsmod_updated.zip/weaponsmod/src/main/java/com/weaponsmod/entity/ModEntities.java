package com.weaponsmod.entity;

import com.weaponsmod.WeaponsMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {

    public static EntityType<BulletEntity> BULLET = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(WeaponsMod.MOD_ID, "bullet"),
            FabricEntityTypeBuilder.<BulletEntity>create(SpawnGroup.MISC, (type, world) -> new BulletEntity(world))
                    .dimensions(EntityDimensions.fixed(0.25f, 0.25f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(4)
                    .build()
    );

    public static EntityType<GrenadeEntity> GRENADE = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(WeaponsMod.MOD_ID, "grenade"),
            FabricEntityTypeBuilder.<GrenadeEntity>create(SpawnGroup.MISC, (type, world) -> new GrenadeEntity(world))
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(4)
                    .build()
    );

    public static void registerEntities() {
        // Called to trigger static initialization
    }
}
