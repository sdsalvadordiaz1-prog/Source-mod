package com.weaponsmod.entity;

import com.weaponsmod.sound.ModSounds;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;

public class GrenadeEntity extends ThrownItemEntity {

    // 5 seconds = 100 ticks before exploding
    private static final int FUSE_TICKS = 100;

    public GrenadeEntity(World world, LivingEntity owner) {
        super(ModEntities.GRENADE, owner, world);
    }

    public GrenadeEntity(World world) {
        super(ModEntities.GRENADE, world);
    }

    @Override
    protected Item getDefaultItem() {
        return Items.FIRE_CHARGE;
    }

    @Override
    protected void onCollision(HitResult hitResult) {
        // Grenade does NOT explode on contact - only after 5 seconds
        // It just bounces (default physics)
    }

    @Override
    public void tick() {
        super.tick();

        // Emit smoke particles while flying (client only)
        if (this.getWorld().isClient) {
            this.getWorld().addParticle(ParticleTypes.SMOKE,
                    this.getX(), this.getY(), this.getZ(),
                    0, 0.02, 0);
        }

        // Explode after exactly 5 seconds (100 ticks)
        if (this.age >= FUSE_TICKS) {
            if (!this.getWorld().isClient) {
                // Play explosion sound
                this.getWorld().playSound(null, this.getBlockPos(),
                        ModSounds.GRENADE_EXPLODE, SoundCategory.PLAYERS, 2.0f, 1.0f);

                // Big explosion that destroys blocks (like creeper)
                this.getWorld().createExplosion(
                        this,
                        this.getX(), this.getY(), this.getZ(),
                        5.0f,   // radius bigger than creeper (4.0)
                        false,  // no fire
                        World.ExplosionSourceType.MOB  // destroys blocks
                );

                // Extra particle burst from server
                if (this.getWorld() instanceof ServerWorld sw) {
                    sw.spawnParticles(ParticleTypes.EXPLOSION_EMITTER,
                            this.getX(), this.getY(), this.getZ(),
                            1, 0, 0, 0, 0);
                    sw.spawnParticles(ParticleTypes.FLAME,
                            this.getX(), this.getY(), this.getZ(),
                            30, 0.5, 0.5, 0.5, 0.1);
                }

                this.discard();
            }
        }
    }
}
