package com.weaponsmod.client.hud;

import com.weaponsmod.item.GunItem;
import com.weaponsmod.item.GunType;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

public class WeaponHudRenderer implements HudRenderCallback {

    // Reload animation state
    private static int reloadAnimTick = 0;
    private static boolean isReloading = false;
    private static int reloadDuration = 0;
    private static int reloadMax = 0;

    public static void startReloadAnim(int durationTicks) {
        isReloading = true;
        reloadAnimTick = 0;
        reloadDuration = durationTicks;
        reloadMax = durationTicks;
    }

    public static void tickReload() {
        if (isReloading) {
            reloadAnimTick++;
            if (reloadAnimTick >= reloadDuration) {
                isReloading = false;
            }
        }
    }

    @Override
    public void onHudRender(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;

        PlayerEntity player = client.player;
        ItemStack heldItem = player.getMainHandStack();

        if (!(heldItem.getItem() instanceof GunItem gunItem)) {
            return;
        }

        GunType gunType = gunItem.getGunType();
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();
        TextRenderer font = client.textRenderer;

        // === AMMO COUNTER (bottom right) ===
        NbtCompound nbt = heldItem.getNbt();
        int loaded = (nbt != null && nbt.contains("LoadedAmmo")) ? nbt.getInt("LoadedAmmo") : 0;
        int maxAmmo = gunType.magazineSize;

        // Count reserve ammo in inventory
        int reserve = 0;
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack inv = player.getInventory().getStack(i);
            if (inv.getItem().getTranslationKey().contains(gunType.ammoId)) {
                reserve += inv.getCount();
            }
        }

        // Color: red if empty, yellow if low (<= 25%), white otherwise
        int ammoColor;
        if (loaded == 0) {
            ammoColor = 0xFF0000; // Red
        } else if (loaded <= maxAmmo / 4) {
            ammoColor = 0xFFAA00; // Orange/Yellow
        } else {
            ammoColor = 0xFFFFFF; // White
        }

        String ammoText = loaded + "/" + reserve;
        String gunName = gunType.displayName;

        int ammoX = screenW - font.getWidth(ammoText) - 10;
        int ammoY = screenH - 30;
        int nameX = screenW - font.getWidth(gunName) - 10;
        int nameY = screenH - 40;

        // Shadow background for readability
        context.fill(nameX - 3, nameY - 2, screenW - 4, ammoY + font.fontHeight + 2, 0x88000000);

        context.drawText(font, gunName, nameX, nameY, 0xAAAAAA, true);
        context.drawText(font, ammoText, ammoX, ammoY, ammoColor, true);

        // === RELOAD ANIMATION BAR ===
        if (isReloading) {
            int barW = 80;
            int barH = 6;
            int barX = screenW / 2 - barW / 2;
            int barY = screenH / 2 + 20;

            context.fill(barX - 1, barY - 1, barX + barW + 1, barY + barH + 1, 0xFF000000);
            float progress = (float) reloadAnimTick / reloadMax;
            context.fill(barX, barY, barX + (int)(barW * progress), barY + barH, 0xFF00FF00);

            String reloadMsg = "Recargando...";
            context.drawText(font, reloadMsg,
                    screenW / 2 - font.getWidth(reloadMsg) / 2,
                    barY + barH + 3, 0xFFFFFF, true);
        }

        // === CROSSHAIR / AIM (only replace default when zoomed) ===
        if (SniperZoomHandler.isZoomed()) {
            // Sniper scope - draw scope lines + dot
            int cx = screenW / 2;
            int cy = screenH / 2;
            int scopeR = 60;

            // Outer circle (approximated with lines)
            drawCircle(context, cx, cy, scopeR, 0xCCFFFFFF);

            // Crosshair lines through scope
            context.fill(cx - scopeR, cy, cx + scopeR, cy + 1, 0xCCFFFFFF);
            context.fill(cx, cy - scopeR, cx + 1, cy + scopeR, 0xCCFFFFFF);

            // Center dot
            context.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFF0000);

            // Range indicator
            String zoomText = "ZOOM";
            context.drawText(font, zoomText,
                    cx - font.getWidth(zoomText) / 2, cy - scopeR - 14, 0xFF00FF00, true);
        } else if (heldItem.getItem() instanceof GunItem) {
            // Custom CS-GO style crosshair
            int cx = screenW / 2;
            int cy = screenH / 2;
            int gap = 4;
            int len = 8;
            int thick = 1;

            // Suppress default crosshair is done via mixin
            // Draw custom crosshair
            context.fill(cx - gap - len, cy - thick/2, cx - gap, cy + thick/2 + 1, 0xFFFFFFFF); // left
            context.fill(cx + gap, cy - thick/2, cx + gap + len, cy + thick/2 + 1, 0xFFFFFFFF); // right
            context.fill(cx - thick/2, cy - gap - len, cx + thick/2 + 1, cy - gap, 0xFFFFFFFF); // up
            context.fill(cx - thick/2, cy + gap, cx + thick/2 + 1, cy + gap + len, 0xFFFFFFFF); // down
            // Center dot
            context.fill(cx, cy, cx + 1, cy + 1, 0xFF00FF00);
        }
    }

    private void drawCircle(DrawContext ctx, int cx, int cy, int r, int color) {
        int segments = 48;
        for (int i = 0; i < segments; i++) {
            double a1 = 2 * Math.PI * i / segments;
            double a2 = 2 * Math.PI * (i + 1) / segments;
            int x1 = (int)(cx + r * Math.cos(a1));
            int y1 = (int)(cy + r * Math.sin(a1));
            int x2 = (int)(cx + r * Math.cos(a2));
            int y2 = (int)(cy + r * Math.sin(a2));
            // Draw a short line between the two points
            drawLine(ctx, x1, y1, x2, y2, color);
        }
    }

    private void drawLine(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;
        while (true) {
            ctx.fill(x1, y1, x1 + 1, y1 + 1, color);
            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x1 += sx; }
            if (e2 < dx) { err += dx; y1 += sy; }
        }
    }
}
