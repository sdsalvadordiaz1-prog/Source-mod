package com.weaponsmod.client.hud;

import com.weaponsmod.item.GunItem;
import com.weaponsmod.item.GunType;
import com.weaponsmod.sound.ModSounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.sound.SoundCategory;

public class SniperZoomHandler {

    private static boolean zoomed = false;
    private static double savedFov = 70.0;

    // FOV when zoomed
    private static final double ZOOM_FOV = 15.0;

    public static boolean isZoomed() {
        return zoomed;
    }

    public static void toggleZoom() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        // Only sniper
        if (!(client.player.getMainHandStack().getItem() instanceof GunItem gun)
                || gun.getGunType() != GunType.SNIPER) {
            if (zoomed) exitZoom();
            return;
        }

        if (!zoomed) {
            enterZoom(client);
        } else {
            exitZoom();
        }
    }

    public static void enterZoom(MinecraftClient client) {
        if (zoomed) return;
        zoomed = true;
        savedFov = client.options.getFov().getValue();
        // Set FOV to zoom
        client.options.getFov().setValue((int) ZOOM_FOV);
        // Block movement - done via mixin
        client.player.getWorld().playSound(
                client.player,
                client.player.getBlockPos(),
                ModSounds.SNIPER_ZOOM_IN,
                SoundCategory.PLAYERS,
                0.5f, 1.0f
        );
    }

    public static void exitZoom() {
        if (!zoomed) return;
        zoomed = false;
        MinecraftClient client = MinecraftClient.getInstance();
        client.options.getFov().setValue((int) savedFov);
        if (client.player != null) {
            client.player.getWorld().playSound(
                    client.player,
                    client.player.getBlockPos(),
                    ModSounds.SNIPER_ZOOM_OUT,
                    SoundCategory.PLAYERS,
                    0.5f, 1.0f
            );
        }
    }

    /**
     * Called every client tick. If zoomed, block movement keys (except W/S for zoom in/out).
     */
    public static void tick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        // If holding sniper + zoomed, block walking
        if (zoomed) {
            // Exit zoom when sneaking
            if (client.player.isSneaking()) {
                exitZoom();
                return;
            }

            // Block forward/back movement (W/S still trigger, but we cancel movement)
            // This is handled via the movement mixin
        }

        // If no longer holding sniper, exit zoom
        if (zoomed && !(client.player.getMainHandStack().getItem() instanceof GunItem gun
                && gun.getGunType() == GunType.SNIPER)) {
            exitZoom();
        }
    }
}
