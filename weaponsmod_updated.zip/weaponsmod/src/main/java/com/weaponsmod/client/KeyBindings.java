package com.weaponsmod.client;

import com.weaponsmod.client.hud.SniperZoomHandler;
import com.weaponsmod.client.hud.WeaponHudRenderer;
import com.weaponsmod.item.GunItem;
import com.weaponsmod.item.GunType;
import com.weaponsmod.network.ReloadPacket;
import com.weaponsmod.network.ZoomPacket;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {

    public static KeyBinding reloadKey;
    public static KeyBinding zoomKey;

    public static void register() {
        reloadKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.weaponsmod.reload",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                "category.weaponsmod.keys"
        ));

        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.weaponsmod.zoom",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_SHIFT,
                "category.weaponsmod.keys"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // Tick HUD reload anim
            WeaponHudRenderer.tickReload();

            // Sniper zoom tick
            SniperZoomHandler.tick();

            // Handle reload key press
            while (reloadKey.wasPressed()) {
                ItemStack held = client.player.getMainHandStack();
                if (held.getItem() instanceof GunItem gun) {
                    int reloadTicks = getReloadTicks(gun.getGunType());
                    WeaponHudRenderer.startReloadAnim(reloadTicks);
                    ClientPlayNetworking.send(ReloadPacket.ID, ReloadPacket.create());
                }
            }

            // Handle zoom key (sniper right-shift)
            while (zoomKey.wasPressed()) {
                ItemStack held = client.player.getMainHandStack();
                if (held.getItem() instanceof GunItem gun && gun.getGunType() == GunType.SNIPER) {
                    SniperZoomHandler.toggleZoom();
                }
            }
        });
    }

    private static int getReloadTicks(GunType type) {
        return switch (type) {
            case PISTOL -> 20;
            case SHOTGUN -> 40;
            case SNIPER -> 60;
            case GRENADE_LAUNCHER -> 30;
            case AK47 -> 35;
            case MINIGUN -> 80;
        };
    }
}
