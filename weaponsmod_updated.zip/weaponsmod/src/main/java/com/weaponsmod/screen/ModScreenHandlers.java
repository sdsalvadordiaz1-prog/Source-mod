package com.weaponsmod.screen;

import com.weaponsmod.WeaponsMod;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

public class ModScreenHandlers {

    public static ScreenHandlerType<WeaponCraftingScreenHandler> WEAPON_CRAFTING;

    public static void registerScreenHandlers() {
        WEAPON_CRAFTING = Registry.register(
                Registries.SCREEN_HANDLER,
                new Identifier(WeaponsMod.MOD_ID, "weapon_crafting"),
                new ScreenHandlerType<>((syncId, inventory) ->
                        new WeaponCraftingScreenHandler(syncId, inventory, ScreenHandlerContext.EMPTY),
                        FeatureFlags.VANILLA_FEATURES)
        );
    }
}
