package com.weaponsmod.sound;

import com.weaponsmod.WeaponsMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {

    public static final SoundEvent PISTOL_FIRE = register("pistol_fire");
    public static final SoundEvent SHOTGUN_FIRE = register("shotgun_fire");
    public static final SoundEvent SNIPER_FIRE = register("sniper_fire");
    public static final SoundEvent AK47_FIRE = register("ak47_fire");
    public static final SoundEvent MINIGUN_FIRE = register("minigun_fire");
    public static final SoundEvent GRENADE_LAUNCH = register("grenade_launch");
    public static final SoundEvent GRENADE_EXPLODE = register("grenade_explode");
    public static final SoundEvent RELOAD = register("reload");
    public static final SoundEvent EMPTY_CLICK = register("empty_click");
    public static final SoundEvent SNIPER_ZOOM_IN = register("sniper_zoom_in");
    public static final SoundEvent SNIPER_ZOOM_OUT = register("sniper_zoom_out");

    private static SoundEvent register(String name) {
        Identifier id = new Identifier(WeaponsMod.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void registerSounds() {
        // trigger static init
    }
}
