package com.weaponsmod;

import com.weaponsmod.block.ModBlocks;
import com.weaponsmod.entity.ModEntities;
import com.weaponsmod.item.ModItems;
import com.weaponsmod.network.ReloadPacket;
import com.weaponsmod.network.ZoomPacket;
import com.weaponsmod.recipe.ModRecipes;
import com.weaponsmod.screen.ModScreenHandlers;
import com.weaponsmod.sound.ModSounds;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WeaponsMod implements ModInitializer {

    public static final String MOD_ID = "weaponsmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModSounds.registerSounds();
        ModItems.registerItems();
        ModBlocks.registerBlocks();
        ModEntities.registerEntities();
        ModScreenHandlers.registerScreenHandlers();
        ModRecipes.registerRecipes();
        ReloadPacket.registerServer();
        ZoomPacket.registerServer();
        LOGGER.info("Weapons Mod loaded! Ready to shoot.");
    }
}
