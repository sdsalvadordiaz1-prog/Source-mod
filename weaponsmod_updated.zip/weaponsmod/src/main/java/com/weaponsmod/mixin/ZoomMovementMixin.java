package com.weaponsmod.mixin;

import com.weaponsmod.client.hud.SniperZoomHandler;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public class ZoomMovementMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(boolean slowDown, float f, CallbackInfo ci) {
        KeyboardInput input = (KeyboardInput)(Object)this;
        if (SniperZoomHandler.isZoomed()) {
            // Block left/right and sprint movement while zoomed
            input.sidewaysMovement = 0;
            input.jumping = false;
            input.sprinting = false;
            // Block forward/backward too
            input.pressingForward = false;
            input.pressingBack = false;
            input.movementForward = 0;
            input.movementSideways = 0;
        }
    }
}
