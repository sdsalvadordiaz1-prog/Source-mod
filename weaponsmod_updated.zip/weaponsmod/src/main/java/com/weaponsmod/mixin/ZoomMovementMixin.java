package com.weaponsmod.mixin;

import com.weaponsmod.client.hud.SniperZoomHandler;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public class ZoomMovementMixin extends Input {

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(boolean slowDown, float f, CallbackInfo ci) {
        if (SniperZoomHandler.isZoomed()) {
            this.movementSideways = 0;
            this.movementForward = 0;
            this.jumping = false;
            this.sneaking = false;
        }
    }
}
